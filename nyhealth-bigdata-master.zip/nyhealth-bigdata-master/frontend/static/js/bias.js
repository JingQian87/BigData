function bias_display(id, raw_Data) {
	console.log(id)
	console.log(raw_Data)
}